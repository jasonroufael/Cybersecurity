# Regular Expressions
Regular expressions are a way to match patterns in text.

## Find a flag in a file
* `grep -oI '\S*DDC\S*' logs.txt`, where DDC is the flag and logs.txt is the file to search in.  
* `grep -oIr '\S*DDC\S*' logs.txt` to search recursively.

# Links
* [RegexOne](https://regexone.com/)