# Setting up Kali

Update repos  
```bash
sudo apt update
```

Inststall metapackage  
```bash
sudo apt install -y kali-linux-default
```

Unzip rockyou  

```bash
sudo gzip -d /usr/share/wordlists/rockyou.txt.gz
```