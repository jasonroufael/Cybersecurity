# Virtual Private Network (VPN)
Virtual Private Network (VPN) is a technology that allows you to create a secure connection over a less-secure network between your computer and the internet. VPNs are used to protect private web traffic from snooping, interference, and censorship. VPNs can also be used to get around regional restrictions on websites or streaming services.

## List of Great VPNs
- [ExpressVPN](https://www.expressvpn.com/)
- [NordVPN](https://nordvpn.com/)
- [Surfshark](https://surfshark.com/)
- [Private Internet Access](https://www.privateinternetaccess.com/)
- [IPVanish](https://www.ipvanish.com/)
- [ProtonVPN](https://protonvpn.com/)
- [HideMyAss](https://www.hidemyass.com/)
- [CyberGhost](https://www.cyberghostvpn.com/)
- [Hotspot Shield](https://www.hotspotshield.com/)
- [TunnelBear](https://www.tunnelbear.com/)
- [PureVPN](https://www.purevpn.com/)
- [Hide.me](https://hide.me/en)
- [VyprVPN](https://www.vyprvpn.com/)
- [StrongVPN](https://www.strongvpn.com/)
- [SaferVPN](https://www.safervpn.com/)
- [Mulvad](https://mullvad.net/en/)
- [IVPN](https://www.ivpn.net/) - My personal go-to VPN!

# OpenVPN
OpenVPN is an open source connection protocol used to facilitate a secure tunnel between two points in a network.

## Installation
**For Windows:**  
`choco install openvpn` 

**For Linux and MacOS:**  
`sudo apt-get install openvpn` 