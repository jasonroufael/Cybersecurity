# Useful Commands
**Get version and build**    
`Get-WmiObject -Class win32_OperatingSystem | select Version,BuildNumber`

**List directories and files in a tree**  
`tree`

**List directories and files**  
`dir c:\ /a`