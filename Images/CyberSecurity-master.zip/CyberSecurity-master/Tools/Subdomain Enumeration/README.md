# How to use
Run: `python3 Subdomain-enumeration.py <link here>` 

Example:
`python3 Subdomain-enumeration.py berkankutuk.dk`
