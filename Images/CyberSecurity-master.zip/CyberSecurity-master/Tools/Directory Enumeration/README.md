# How to use
Run: `python3 Directory-enumeration.py <link here>` 

Example:
`python3 Directory-enumeration.py gnu.org`
